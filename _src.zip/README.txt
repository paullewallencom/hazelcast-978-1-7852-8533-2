Getting Started with Hazelcast
------------------------------

For ease of use you can use Maven to setup an Eclipse or Intellij project.

This will download the appropriate artifacts from the Maven central repository.

The code is structured with each chapter separated into it's own sub-project to
make it easier to follow along with the book.
